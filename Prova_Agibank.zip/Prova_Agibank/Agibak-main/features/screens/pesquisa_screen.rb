# frozen_string_literal: true
require 'hooks.rb'

class PesquisaPage
  def initialize
    # ---------------------- elements ----------------------
    @lupaPesquisar = find(:xpath, "//span[@class='screen-reader-text'][text()='Pesquisar']")
    @localizacampoPesquisa = find(:id, "search-field")
    @localizaresultadopesquisa = find(:xpath, "//span[@class='screen-reader-text'][text()="@descResultadoBusca"]")
  end


  def TelaInicial
    xvisit 'https://blogdoagi.com.br/'
    expect(page).to have_content('Blog do Agi')
  end

   def btnPesquisar
    find_element(:id, lupaPesquisar).click
  end
  
  def campoPesquisa(descPesquisa)
    find_element(:id, localizacampoPesquisa.send_keys("descPesquisa")
    find_element(:id, localizacampoPesquisa.send_keys("ENTER")
  end


  def resultadoBusca(descResultadoBusca)
    find_element(:id, localizaresultadopesquisa).text
    return descResultadoBusca
  end
end