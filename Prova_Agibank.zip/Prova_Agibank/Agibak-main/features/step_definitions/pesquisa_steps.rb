Dado('que eu esteja na tela inicial do blog') do
  @Pesquisa.TelaInicial
end

Quando('clico no botão pesquisar') do
  @Pesquisa.btnPesquisar
end

Quando('preencho a pesquisa com o valor '@DescricaoPesquisa'') do
	@Pesquisa.campoPesquisa(@DescricaoPesquisa)
end

Então('deve ser exibido no resultado a descrição'@resultadodaBusca'') do
  expect(@Pesquisa.resultadoBusca).to eq(resultadodaBuscar)
end