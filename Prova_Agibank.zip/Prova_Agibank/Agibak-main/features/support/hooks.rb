# frozen_string_literal: true

require 'capybara/rspec'
require 'selenium-webdriver'

Capybara.configure do |config|
  config.default_driver = :selenium_chrome # Ou :selenium_firefox para usar Firefox
  config.default_max_wait_time = 5 # Tempo m�ximo de espera para elementos aparecerem
end
