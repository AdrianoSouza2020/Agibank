# frozen_string_literal: true

require 'rspec'
require 'selenium-cucumber'
require 'appium_lib'
require 'pry'
require 'selenium-webdriver'
require 'httparty'